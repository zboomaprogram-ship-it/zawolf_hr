const admin = require('firebase-admin');
const { fetchSalesAnalytics } = require('./sales-analytics-client');
const { initializeFirebase } = require('./dispatch-notifications');

const SOURCE = 'sales_analytics_api';
const SYSTEM_ACTOR = 'sales-analytics-sync';

function number(value) {
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : 0;
}

function normalize(value) {
  return String(value || '')
    .trim()
    .toLocaleLowerCase('en')
    .replace(/[\s._-]+/g, '');
}

function dateKey(date) {
  return [
    date.getUTCFullYear(),
    String(date.getUTCMonth() + 1).padStart(2, '0'),
    String(date.getUTCDate()).padStart(2, '0'),
  ].join('-');
}

function cycleFor(date = new Date()) {
  const parts = new Intl.DateTimeFormat('en-US', {
    timeZone: 'Africa/Cairo',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  }).formatToParts(date);
  const value = Object.fromEntries(
    parts.filter((part) => part.type !== 'literal')
      .map((part) => [part.type, Number(part.value)]),
  );
  const cairoDate = new Date(Date.UTC(value.year, value.month - 1, value.day));
  const endMonth = cairoDate.getUTCDate() <= 25
    ? new Date(Date.UTC(cairoDate.getUTCFullYear(), cairoDate.getUTCMonth(), 1))
    : new Date(Date.UTC(cairoDate.getUTCFullYear(), cairoDate.getUTCMonth() + 1, 1));
  const start = new Date(Date.UTC(
    endMonth.getUTCFullYear(),
    endMonth.getUTCMonth() - 1,
    26,
  ));
  const end = new Date(Date.UTC(
    endMonth.getUTCFullYear(),
    endMonth.getUTCMonth(),
    25,
  ));
  return {
    monthKey: `${end.getUTCFullYear()}-${String(end.getUTCMonth() + 1).padStart(2, '0')}`,
    start,
    end,
    startDate: dateKey(start),
    endDate: dateKey(end),
  };
}

function agentIdentifiers(agent) {
  if (typeof agent === 'string') return [normalize(agent)];
  if (!agent || typeof agent !== 'object') return [];
  return [
    agent.id,
    agent.agentId,
    agent.employeeId,
    agent.employeeCode,
    agent.code,
    agent.key,
    agent.email,
    agent.name,
    agent.displayName,
    agent.label,
    agent.sales,
    agent.teleSales,
  ].map(normalize).filter(Boolean);
}

function agentActual(agent, counts) {
  if (typeof agent === 'number') return number(agent);
  if (typeof agent === 'string') {
    const expected = normalize(agent);
    const match = Object.entries(counts || {}).find(
      ([key]) => normalize(key) === expected,
    );
    return number(match?.[1]);
  }
  if (!agent || typeof agent !== 'object') {
    return 0;
  }
  const values = [
    agent.actual,
    agent.achieved,
    agent.value,
    agent.total,
    agent.amount,
    agent.count,
    agent.totalPrice,
    agent.confirmedMeetings,
  ];
  for (const value of values) {
    const parsed = Number(value);
    if (Number.isFinite(parsed)) return parsed;
  }
  const normalizedCounts = new Map(
    Object.entries(counts || {}).map(([key, value]) => [normalize(key), value]),
  );
  for (const id of agentIdentifiers(agent)) {
    if (normalizedCounts.has(id)) {
      return number(normalizedCounts.get(id));
    }
  }
  return 0;
}

function findAgent(kpiData, user) {
  const expected = new Set([
    user.salesAnalyticsAgentKey,
    user.employeeId,
    user.email,
    user.displayName,
  ].map(normalize).filter(Boolean));
  const agents = Array.isArray(kpiData?.agents)
    ? kpiData.agents
    : Object.entries(kpiData?.agents || {}).map(([key, value]) => (
      value && typeof value === 'object' ? { key, ...value } : { key, actual: value }
    ));
  return agents.find((agent) =>
    agentIdentifiers(agent).some((id) => expected.has(id)),
  );
}

function weightedProgress(metrics) {
  const totalWeight = metrics.reduce((sum, metric) => sum + number(metric.weight), 0);
  if (!totalWeight) return 0;
  const weighted = metrics.reduce((sum, metric) => {
    if (!metric.target) return sum;
    const completion = Math.min(150, Math.max(0, (metric.actual / metric.target) * 100));
    return sum + completion * number(metric.weight);
  }, 0);
  return Math.min(100, weighted / totalWeight);
}

function taskDueDates(cycle, count) {
  const range = cycle.end.getTime() - cycle.start.getTime();
  return Array.from({ length: count }, (_, index) => new Date(
    cycle.start.getTime() + Math.round(range * ((index + 1) / count)),
  ));
}

function notificationData(type, title, body, data) {
  return {
    type,
    title,
    body,
    data,
    isRead: false,
    pushSent: false,
    pushAttemptCount: 0,
    createdAt: admin.firestore.FieldValue.serverTimestamp(),
  };
}

async function upsertEmployeeKpi(db, userDoc, api, cycle, options) {
  const user = { uid: userDoc.id, ...userDoc.data() };
  const role = String(user.salesAnalyticsRole || '').toLowerCase();
  const kpiData = role.includes('tele') ? api.teleSalesKpi : api.salesKpi;
  const agent = findAgent(kpiData, user);
  if (!agent) return { matched: false, userId: user.uid };

  const metricKey = role.includes('tele') ? 'tele_sales_target' : 'sales_target';
  const metric = {
    key: metricKey,
    source: SOURCE,
    editable: false,
    name: role.includes('tele') ? 'تحقيق هدف المبيعات الهاتفية' : 'تحقيق هدف المبيعات',
    unit: role.includes('tele') ? 'اجتماع' : 'قيمة',
    target: number(kpiData?.target),
    actual: agentActual(agent, kpiData?.counts),
    weight: 100,
    direction: 'higher_is_better',
    evidenceUrl: '',
    managerComment: 'يتم تحديث هذا المؤشر تلقائياً من نظام المبيعات.',
  };
  const kpiId = `${user.uid}_${cycle.monthKey}`;
  const kpiRef = db.collection('employeeKpis').doc(kpiId);
  const existing = await kpiRef.get();
  const existingData = existing.data() || {};
  const manualMetrics = (existingData.metrics || []).filter(
    (item) => item.source !== SOURCE,
  );
  const metrics = [...manualMetrics, metric];
  const now = admin.firestore.FieldValue.serverTimestamp();
  await kpiRef.set({
    templateId: existingData.templateId || SOURCE,
    userId: user.uid,
    employeeId: user.employeeId || '',
    employeeName: user.displayName || '',
    department: user.department || '',
    managerId: user.managerId || user.managerIds?.[0] || '',
    managerIds: user.managerIds || (user.managerId ? [user.managerId] : []),
    monthKey: cycle.monthKey,
    status: existingData.status || 'active',
    metrics,
    overallProgress: weightedProgress(metrics),
    createdBy: existingData.createdBy || SYSTEM_ACTOR,
    createdAt: existingData.createdAt || now,
    updatedAt: now,
    externalSource: SOURCE,
    periodStart: cycle.startDate,
    periodEnd: cycle.endDate,
    lastSyncedAt: now,
    syncStatus: 'synced',
  }, { merge: true });

  const taskCount = options.taskCount;
  let createdTasks = 0;
  const milestonesReady =
    number(existingData.milestonesGenerated) >= taskCount &&
    existingData.milestonePeriodKey === cycle.monthKey;
  if (options.tasksEnabled && taskCount > 0 && !milestonesReady) {
    const dueDates = taskDueDates(cycle, taskCount);
    const targetPerTask = taskCount ? metric.target / taskCount : metric.target;
    for (let index = 0; index < taskCount; index++) {
      const taskId = `sales_kpi_${cycle.monthKey}_${user.uid}_${metricKey}_${index + 1}`;
      const taskRef = db.collection('tasks').doc(taskId);
      const taskExists = await taskRef.get();
      await taskRef.set({
        title: `${metric.name} - المرحلة ${index + 1} من ${taskCount}`,
        description:
          `هدف مرحلي تلقائي لدورة ${cycle.startDate} إلى ${cycle.endDate}. ` +
          `المطلوب في هذه المرحلة: ${targetPerTask.toFixed(2)} ${metric.unit}.`,
        assigneeId: user.uid,
        assigneeName: user.displayName || '',
        assigneeEmployeeId: user.employeeId || '',
        department: user.department || '',
        managerId: user.managerId || user.managerIds?.[0] || '',
        managerIds: user.managerIds || (user.managerId ? [user.managerId] : []),
        createdBy: SYSTEM_ACTOR,
        createdByName: 'نظام مؤشرات المبيعات',
        priority: 'high',
        status: taskExists.data()?.status || 'new',
        dueDate: admin.firestore.Timestamp.fromDate(dueDates[index]),
        createdAt: taskExists.data()?.createdAt || now,
        updatedAt: now,
        isRead: taskExists.data()?.isRead || false,
        source: SOURCE,
        sourceId: kpiId,
        sourceMetricKey: metricKey,
        periodKey: cycle.monthKey,
        milestoneNumber: index + 1,
        targetValue: targetPerTask,
        actualValue: metric.actual,
        targetUnit: metric.unit,
      }, { merge: true });
      if (!taskExists.exists) {
        createdTasks++;
        await db.collection('notifications').doc(user.uid).collection('items')
          .doc(`task_${taskId}`)
          .set(notificationData(
            'task_assigned',
            'تم إنشاء مهمة KPI جديدة',
            `تم تقسيم هدف ${cycle.monthKey} إلى مرحلة ${index + 1} من ${taskCount}.`,
            { taskId, employeeKpiId: kpiId, route: '/employee/tasks' },
          ));
      }
    }
    await kpiRef.set({
      milestonesGenerated: taskCount,
      milestonePeriodKey: cycle.monthKey,
      updatedAt: now,
    }, { merge: true });
  }
  return { matched: true, userId: user.uid, kpiId, createdTasks };
}

async function syncSalesKpis(input = {}) {
  initializeFirebase();
  const db = admin.firestore();
  const cycle = input.startDate && input.endDate
    ? {
        ...cycleFor(),
        startDate: input.startDate,
        endDate: input.endDate,
      }
    : cycleFor(input.now);
  const api = await fetchSalesAnalytics({
    startDate: cycle.startDate,
    endDate: cycle.endDate,
    company: input.company || process.env.SALES_API_COMPANY || 'ALL',
    salesTarget: input.salesTarget || process.env.SALES_API_SALES_TARGET,
    teleTarget: input.teleTarget || process.env.SALES_API_TELE_TARGET,
  });
  const usersSnap = await db.collection('users')
    .where('salesAnalyticsEnabled', '==', true)
    .get();
  const options = {
    tasksEnabled: String(process.env.SALES_KPI_TASKS_ENABLED || 'true') !== 'false',
    taskCount: Math.min(8, Math.max(1, Number(process.env.SALES_KPI_TASK_COUNT || 4))),
  };
  const results = [];
  for (const userDoc of usersSnap.docs) {
    results.push(await upsertEmployeeKpi(db, userDoc, api, cycle, options));
  }
  const matched = results.filter((item) => item.matched);
  const summary = api.summary || {};
  const snapshot = {
    periodKey: cycle.monthKey,
    periodStart: cycle.startDate,
    periodEnd: cycle.endDate,
    totalLeads: number(summary.totalLeads),
    confirmedMeetings: number(summary.confirmedMeetings),
    closings: number(summary.closings),
    paidCustomers: number(summary.paidCustomers),
    totalPrice: number(summary.totalPrice),
    downPayment: number(summary.downPayment),
    monthlyIncome: number(summary.monthlyIncome),
    monthlyGrowthRate: number(summary.monthlyGrowthRate),
    teleConversionRate: number(summary.teleConversionRate),
    salesConversionRate: number(summary.salesConversionRate),
    generatedAt: api.generatedAt || '',
    sourceWarnings: Array.isArray(api.source?.warnings)
      ? api.source.warnings.map(String).slice(0, 10)
      : [],
    salesTarget: number(api.salesKpi?.target),
    teleSalesTarget: number(api.teleSalesKpi?.target),
    mappedEmployees: matched.length,
    unmatchedEmployees: results.length - matched.length,
    createdTasks: matched.reduce((sum, item) => sum + item.createdTasks, 0),
    syncedAt: admin.firestore.FieldValue.serverTimestamp(),
  };
  await db.collection('salesKpiSummaries').doc(cycle.monthKey).set(snapshot);
  await db.collection('salesKpiSummaries').doc('current').set(snapshot);
  return {
    periodKey: cycle.monthKey,
    users: results.length,
    matched: matched.length,
    unmatched: results.length - matched.length,
    createdTasks: snapshot.createdTasks,
  };
}

if (require.main === module) {
  syncSalesKpis()
    .then((result) => console.log('Sales KPI sync complete:', result))
    .catch((error) => {
      console.error('Sales KPI sync failed:', error.message || error);
      process.exitCode = 1;
    });
}

module.exports = {
  syncSalesKpis,
  cycleFor,
  normalize,
  agentIdentifiers,
  agentActual,
  findAgent,
  taskDueDates,
};
