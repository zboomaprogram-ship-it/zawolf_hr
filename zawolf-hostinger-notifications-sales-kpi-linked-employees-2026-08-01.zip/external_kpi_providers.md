# External KPI Providers

The KPI integration is provider-based. Sales Analytics is the first provider,
but employee screens, daily tasks, history, and dashboards consume normalized
Firestore documents rather than depending on the provider response directly.

## Current Provider: Sales Analytics

- Employee matching: `employeeId` is sent as `idEmp`.
- Sales employees use the sales amount metric and a SAR target.
- Telesales employees use the telesales activity metric and its own target.
- The monthly result is divided across the employee's eligible workdays.
- Company days off, approved leave, and employee non-workdays do not create
  daily KPI tasks.
- Daily tasks store cumulative target and actual values so delayed upstream
  data does not incorrectly mark every previous day as missed.

## Normalized Output

Every future provider should produce:

- provider type and metric key
- employee ID
- period start and end
- target and actual value
- unit/currency
- daily eligible dates
- performance state (`ahead`, `on_track`, or `behind`)
- a deterministic task ID for idempotent synchronization

## Adding Another Provider

1. Add a backend API client under `scripts/`.
2. Map the provider response to the normalized KPI fields.
3. Create deterministic daily tasks using the same workday/leave exclusions.
4. Write provider summaries and employee KPI snapshots to Firestore.
5. Add the provider to the dashboard summary without changing task behavior.

Provider API keys must remain on Hostinger. They must never be included in the
Flutter or web build.
