const test = require("node:test");
const assert = require("node:assert/strict");

const {
  isEligiblePermissionCandidate,
  nextApprovalStage,
  permissionCycleForRequestDate,
  reconcileFinalizedPermissions,
  shouldUpdateActivePermissionBalance,
} = require("../manager-leave-permission-bypass");

test("startup reconciliation has a bounded payroll-period permission scan", async () => {
  const filters = [];
  const db = {
    collection() {
      return {
        where(field, operator, value) {
          filters.push([field, operator, value]);
          return this;
        },
        limit(value) {
          assert.equal(value, 250);
          return this;
        },
        async get() {
          return { docs: [], size: 0 };
        },
      };
    },
  };

  const result = await reconcileFinalizedPermissions(
    db,
    new Date("2026-09-13T12:00:00.000Z"),
  );

  assert.equal(result.found, 0);
  assert.deepEqual(
    filters.map(([field, operator]) => [field, operator]),
    [
      ["requestDate", ">="],
      ["requestDate", "<="],
    ],
  );
});

test("manager leave bypass applies only to same-day time permissions", () => {
  const base = {
    requestDate: "2026-07-27",
    managerId: "manager-1",
  };

  assert.equal(
    isEligiblePermissionCandidate(
      { ...base, permissionType: "late_arrival" },
      "2026-07-27",
    ),
    true,
  );
  assert.equal(
    isEligiblePermissionCandidate(
      { ...base, permissionType: "late_arrival" },
      "2026-07-28",
    ),
    false,
  );
  assert.equal(
    isEligiblePermissionCandidate(
      { ...base, permissionType: "annual_leave" },
      "2026-07-27",
    ),
    false,
  );
});

test("manager leave bypass continues to the next assigned manager", () => {
  assert.deepEqual(
    nextApprovalStage({
      managerIds: ["direct", "higher"],
      managerId: "direct",
      managerApprovalIndex: 0,
      requiresHrApproval: true,
    }),
    {
      status: "pending_manager",
      managerId: "higher",
      managerApprovalIndex: 1,
    },
  );
});

test("manager leave bypass continues to HR when policy requires HR", () => {
  assert.equal(
    nextApprovalStage({
      managerIds: ["direct"],
      managerId: "direct",
      managerApprovalIndex: 0,
      requiresHrApproval: true,
    }).status,
    "pending_hr",
  );
});

test("manager leave bypass finalizes when HR is not required", () => {
  assert.equal(
    nextApprovalStage({
      managerIds: ["direct"],
      managerId: "direct",
      managerApprovalIndex: 0,
      requiresHrApproval: false,
    }).status,
    "approved",
  );
});

test("late approval cannot consume the next payroll cycle balance", () => {
  const oldPermission = { requestDate: "2026-07-22" };
  const employeeInNewCycle = {
    permissionBalance: { lastResetMonth: "2026-08" },
  };
  assert.equal(
    permissionCycleForRequestDate(oldPermission.requestDate),
    "2026-07",
  );
  assert.equal(
    shouldUpdateActivePermissionBalance(oldPermission, employeeInNewCycle),
    false,
  );
  assert.equal(
    shouldUpdateActivePermissionBalance(
      { requestDate: "2026-07-26" },
      employeeInNewCycle,
    ),
    true,
  );
});
