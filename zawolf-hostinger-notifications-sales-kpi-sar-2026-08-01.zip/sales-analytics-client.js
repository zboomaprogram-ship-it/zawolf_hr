const DEFAULT_BASE_URL = 'https://kpi.samielmetwali.com';

class SalesAnalyticsError extends Error {
  constructor(message, statusCode = 0) {
    super(message);
    this.name = 'SalesAnalyticsError';
    this.statusCode = statusCode;
  }
}

function requiredConfig() {
  const apiKey = String(process.env.SALES_API_KEY || '').trim();
  if (!apiKey) {
    throw new SalesAnalyticsError('SALES_API_KEY is required.');
  }
  return {
    apiKey,
    baseUrl: String(process.env.SALES_API_BASE_URL || DEFAULT_BASE_URL)
      .replace(/\/+$/, ''),
    timeoutMs: Math.max(5000, Number(process.env.SALES_API_TIMEOUT_MS || 20000)),
  };
}

async function fetchSalesAnalytics(params, fetchImpl = globalThis.fetch) {
  if (typeof fetchImpl !== 'function') {
    throw new SalesAnalyticsError('This Node runtime does not provide fetch.');
  }
  const { apiKey, baseUrl, timeoutMs } = requiredConfig();
  const url = new URL(`${baseUrl}/api/v1/sales-analytics`);
  for (const [key, value] of Object.entries(params)) {
    if (value !== undefined && value !== null && value !== '') {
      url.searchParams.set(key, String(value));
    }
  }
  url.searchParams.set('includeRows', 'false');
  url.searchParams.set('limit', '100');
  url.searchParams.set('offset', '0');

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const response = await fetchImpl(url, {
      headers: {
        accept: 'application/json',
        authorization: `Bearer ${apiKey}`,
      },
      signal: controller.signal,
    });
    const text = await response.text();
    let body;
    try {
      body = text ? JSON.parse(text) : {};
    } catch (_) {
      throw new SalesAnalyticsError(
        `Sales Analytics returned invalid JSON (${response.status}).`,
        response.status,
      );
    }
    if (!response.ok) {
      const apiError = body?.error;
      throw new SalesAnalyticsError(
        body?.message ||
          apiError?.message ||
          (typeof apiError === 'string' ? apiError : '') ||
          `Sales Analytics failed (${response.status}).`,
        response.status,
      );
    }
    if (body?.success === false || !body?.summary) {
      throw new SalesAnalyticsError(
        body?.message || 'Sales Analytics returned an incomplete response.',
        response.status,
      );
    }
    return body;
  } catch (error) {
    if (error?.name === 'AbortError') {
      throw new SalesAnalyticsError('Sales Analytics request timed out.');
    }
    throw error;
  } finally {
    clearTimeout(timeout);
  }
}

module.exports = { fetchSalesAnalytics, SalesAnalyticsError };
