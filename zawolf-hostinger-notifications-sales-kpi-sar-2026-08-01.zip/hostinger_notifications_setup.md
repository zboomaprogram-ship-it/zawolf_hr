# Hostinger Notifications Setup

This deploys a small Node.js web app on Hostinger to send OneSignal push
notifications from Firestore notification records. It also creates trusted
attendance reminders at the exact time they should be sent.

## What It Does

1. The Flutter app creates a document under `notifications/{userId}/items`.
2. The running Hostinger service scans and sends requests, tasks, approvals,
   and all other app notifications automatically once per minute.
3. The dispatcher sends the push through OneSignal.
4. The notification document is marked as `pushSent: true`.
5. The running Hostinger service scans attendance reminders every five minutes. This checks the
   user's shift, Friday, company days off, approved personal leave, approved
   late-arrival permission, approved early-leave permission, and today's
   attendance before creating a reminder.

## Hostinger Web App

In Hostinger hPanel:

1. Open **Websites**.
2. Click **Add website**.
3. Choose **Deploy Web App**.
4. Deploy from GitHub or upload the project.
5. Set the app root/directory to:

```text
scripts
```

6. Set the framework preset to **Other**, then set the entry file to:

```text
notification-web.js
```

7. Set the build command to `npm run build` (never use `npm start` as the
build command). The project provides a successful no-op build command because
this is a server, not a front-end bundle.

```bash
npm run build
```

8. If Hostinger shows a start command, set it to:

```bash
npm start
```

9. Add environment variables:

```text
FIREBASE_SERVICE_ACCOUNT
ONESIGNAL_APP_ID
ONESIGNAL_REST_API_KEY
NOTIFICATION_DISPATCH_SECRET
NOTIFICATION_DISPATCH_BATCH_SIZE=100
NOTIFICATION_DISPATCH_PER_USER_LIMIT=20
NOTIFICATION_DISPATCH_MAX_ATTEMPTS=5
NOTIFICATION_DISPATCH_INTERVAL_MS=300000
```

Use a long random value for `NOTIFICATION_DISPATCH_SECRET`.

To enable the Sales KPI integration, also add:

```text
SALES_API_KEY=ROTATED_SECRET_VALUE
SALES_API_BASE_URL=https://kpi.samielmetwali.com
SALES_API_COMPANY=ALL
SALES_API_TIMEOUT_MS=20000
SALES_KPI_TASKS_ENABLED=true
SALES_KPI_TASK_COUNT=4
```

Keep `SALES_API_KEY` only in Hostinger. Never place it in Flutter, Firebase,
GitHub, or the uploaded ZIP.

Upload only the prepared `zawolf-hostinger-notifications.zip` package, or a
folder containing `package.json`, `package-lock.json`, `notification-web.js`,
`dispatch-notifications.js`, `attendance-reminders.js`, `auto-attendance.js`,
`manager-leave-permission-bypass.js`, `onesignal.js`,
`firebase-service-account.js`, `sales-analytics-client.js`, and
`sync-sales-kpis.js`. Do not upload `node_modules`, CSV files, admin scripts,
service-account files, or `.DS_Store`.

## Test The Web App

Open:

```text
https://YOUR-HOSTINGER-APP-DOMAIN/health
```

Expected result:

```json
{"ok":true,"service":"zawolf-notification-dispatcher"}
```

Then test dispatch:

Use an HTTP header instead of putting the secret in a URL, which can be saved
in browser history and server logs:

```bash
curl -fsS -H "X-Notification-Dispatch-Secret: YOUR_SECRET" \
  "https://YOUR-HOSTINGER-APP-DOMAIN/dispatch"
```

Expected result:

```json
{"ok":true,"found":0,"sent":0,"failed":0}
```

If there are pending notifications, `found` and `sent` should be greater than
zero.

Test the attendance reminder endpoint too:

```bash
curl -fsS -H "X-Notification-Dispatch-Secret: YOUR_SECRET" \
  "https://YOUR-HOSTINGER-APP-DOMAIN/attendance-reminders"
```

It may correctly return `queued: 0` outside a reminder time window.

Test Sales KPI synchronization:

```bash
curl -fsS -H "X-Notification-Dispatch-Secret: YOUR_SECRET" \
  "https://YOUR-HOSTINGER-APP-DOMAIN/sales-kpi/sync"
```

The first successful run creates the current KPI records, monthly employee
tasks, and task notifications. Repeated runs update progress without
duplicating the same month's tasks.

## Optional Cron Backup

No Hostinger cron job is required after deploying the current package. The
Node service now dispatches notifications and scans attendance reminders itself
once per minute. The endpoints below are still useful as an optional backup or
for manual testing.

Normal app notifications:

```bash
curl -fsS -H "X-Notification-Dispatch-Secret: YOUR_SECRET" \
  "https://YOUR-HOSTINGER-APP-DOMAIN/dispatch" >/dev/null 2>&1
```

Attendance reminders:

```bash
curl -fsS -H "X-Notification-Dispatch-Secret: YOUR_SECRET" \
  "https://YOUR-HOSTINGER-APP-DOMAIN/attendance-reminders" >/dev/null 2>&1
```

If you choose to keep a backup cron job, use this schedule:

```text
Every 5 minutes
```

Sales KPI synchronization should use a separate four-hour cron schedule:

```text
0 */4 * * *
```

Call `/sales-kpi/sync` with the same protected HTTP header. Four-hour
synchronization keeps the dashboard and employee progress current without
unnecessary Firestore or Sales API usage.

Server reminders work even when the app is closed or terminated, provided the
phone has allowed notifications and OneSignal shows the device as subscribed.

## GitHub Actions Backup

After Hostinger is working, keep `.github/workflows/dispatch-notifications.yml`
as a manual backup. You can disable its schedule later if Hostinger is reliable.

## Troubleshooting

- If `/health` fails: the Hostinger Node app is not running.
- If `/dispatch` returns `Unauthorized`: the secret is missing or wrong.
- If `/dispatch` says OneSignal keys are required: check Hostinger environment
  variables.
- If `sent` stays zero: make sure the Flutter app created unread notification
  documents and users logged in once after OneSignal was added.
- If OneSignal returns alias/player errors: open the app on the target phone and
  log in once so `OneSignal.login(firebaseUid)` is registered.
- If `/sales-kpi/sync` reports an authentication error: rotate and re-enter
  `SALES_API_KEY` in Hostinger, then redeploy.
- If an enabled employee is unmatched: edit the employee and set their Sales
  API agent key exactly as returned by the Sales Analytics API.
- For a lock-screen test: close the app, have an employee submit a permission
  request, wait for the next five-minute dispatch, and verify that HR receives
  a push. Then approve/reject it and verify the employee receives one.
